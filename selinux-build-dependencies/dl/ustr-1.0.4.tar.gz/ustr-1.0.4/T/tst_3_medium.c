#undef  USTR_CONF_REF_BYTES
#define USTR_CONF_REF_BYTES 2
#define USTR_CONF_USE_CONSTx_EOS_MARK 0
#define ustr_cntl_opt(x, y) 0 /* return FALSE */
