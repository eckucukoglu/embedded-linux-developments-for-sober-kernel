#undef  USTR_CONF_REF_BYTES
#define USTR_CONF_REF_BYTES 0

#include "ctst_10_b.c"
