#undef  USTR_CONF_REF_BYTES
#define USTR_CONF_REF_BYTES 0
#define ustr_cntl_opt(x, y) 0 /* return FALSE */
