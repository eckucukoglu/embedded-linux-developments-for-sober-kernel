#! /bin/sh -e

# From http://www.and.org/hacks/git-push-web.sh

git-push-web.sh tst:public_html/ustr/ustr.git
